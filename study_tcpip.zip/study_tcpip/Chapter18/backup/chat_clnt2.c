#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define BUF_SIZE 256
#define MAX_ROOM_NAME 30

void error_handling(const char *msg);
void send_message(int sock, const char *message);
void receive_message(int sock);

int main(int argc, char *argv[])
{
    int sock;
    struct sockaddr_in serv_addr;
    char message[BUF_SIZE];
    char response[MAX_ROOM_NAME + 1];  // Buffer size for room name

    if (argc != 3) {
        fprintf(stderr, "Usage: %s <IP> <PORT>\n", argv[0]);
        exit(1);
    }

    sock = socket(PF_INET, SOCK_STREAM, 0);
    if (sock == -1)
        error_handling("socket() error");

    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(argv[1]);
    serv_addr.sin_port = htons(atoi(argv[2]));

    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == -1)
        error_handling("connect() error");

    while (1) {
        // Display menu
        printf("1. Create Room\n2. List Rooms\n3. Enter Room\n4. Leave Room\n5. Exit\n");
        printf("Select an option: ");
        if (fgets(message, sizeof(message), stdin) == NULL)
            error_handling("fgets() error");
        message[strcspn(message, "\n")] = '\0';  // Remove newline character

        if (strcmp(message, "1") == 0) {
            // Create Room
            printf("Enter room name (max %d characters): ", MAX_ROOM_NAME);
            if (fgets(response, sizeof(response), stdin) == NULL)
                error_handling("fgets() error");
            response[strcspn(response, "\n")] = '\0';  // Remove newline character

            // Ensure room name fits into the buffer
            if (strlen(response) < MAX_ROOM_NAME) {
                snprintf(message, sizeof(message), "create_room %s", response);
                send_message(sock, message);
                receive_message(sock); // Receive confirmation
            } else {
                printf("Room name is too long. Please limit to %d characters.\n", MAX_ROOM_NAME - 1);
            }
        }
        else if (strcmp(message, "2") == 0) {
            // List Rooms
            send_message(sock, "list_rooms");
            receive_message(sock);
        }
        else if (strcmp(message, "3") == 0) {
            // Enter Room
            printf("Enter room name (max %d characters): ", MAX_ROOM_NAME);
            if (fgets(response, sizeof(response), stdin) == NULL)
                error_handling("fgets() error");
            response[strcspn(response, "\n")] = '\0';  // Remove newline character

            // Ensure room name fits into the buffer
            if (strlen(response) < MAX_ROOM_NAME) {
                snprintf(message, sizeof(message), "enter_room %s", response);
                send_message(sock, message);
                receive_message(sock); // Receive confirmation
            } else {
                printf("Room name is too long. Please limit to %d characters.\n", MAX_ROOM_NAME - 1);
            }
        }
        else if (strcmp(message, "4") == 0) {
            // Leave Room
            send_message(sock, "leave_room");
            receive_message(sock); // Receive confirmation
        }
        else if (strcmp(message, "5") == 0) {
            // Exit
            send_message(sock, "exit");
            break;
        }
        else {
            printf("Invalid option. Please try again.\n");
        }

        // Receive and print the server's response
        receive_message(sock);
    }

    close(sock);
    return 0;
}

void send_message(int sock, const char *message)
{
    ssize_t sent_bytes = write(sock, message, strlen(message));
    if (sent_bytes == -1)
        error_handling("write() error");
    if (sent_bytes < (ssize_t)strlen(message))
        fprintf(stderr, "Warning: Partial write occurred. Sent %ld of %zu bytes.\n", sent_bytes, strlen(message));
}

void receive_message(int sock)
{
    char message[BUF_SIZE];
    ssize_t str_len = read(sock, message, sizeof(message) - 1);
    if (str_len == -1)
        error_handling("read() error");
    if (str_len == 0) {
        printf("Server disconnected.\n");
        exit(1);
    }

    message[str_len] = '\0';  // Null-terminate the string
    printf("Server: %s\n", message);
}

void error_handling(const char *msg)
{
    perror(msg);
    exit(1);
}
/*
    메뉴: 사용자가 선택할 수 있는 옵션을 제공하며, 방 생성 시 자동으로 방에 입장하도록 합니다.
    입력 및 출력: 서버와의 메시지 송수신을 통해 서버의 응답을 표시합니다.
    수정 사항 설명
    MAX_ROOM_NAME 정의: 방 이름의 최대 길이를 30으로 정의했습니다.
    response 배열 크기 조정: response 배열의 크기를 MAX_ROOM_NAME + 1로 설정하여 방 이름의 최대 길이를 고려합니다.
    방 이름 길이 확인: create_room 및 enter_room 명령을 처리할 때 방 이름의 길이를 확인하고, 버퍼 크기를 초과하지 않도록 합니다.
    출력 형식 조정: snprintf 호출 시 response의 길이를 제한하여 message 버퍼가 초과되지 않도록 합니다.
    이 수정 사항을 통해 방 이름이 버퍼 크기를 초과하지 않도록 하여 경고 메시지를 해결할 수 있습니다.
 */