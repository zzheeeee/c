#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>

#define BUF_SIZE 256
#define MAX_CLNT 256
#define MAX_ROOM 50
#define MAX_ROOM_NAME 30

void *handle_clnt(void *arg);
void send_msg_to_room(const char *msg, const char *room_name);
void error_handling(const char *msg);
void create_room(const char *room_name);
void list_rooms(int sock);
void enter_room(int sock, const char *room_name);
void leave_room(int sock);

int clnt_cnt = 0;
int clnt_socks[MAX_CLNT];
pthread_mutex_t mutx;

typedef struct Room {
    char name[MAX_ROOM_NAME];
    int clnt_count;
    int clnt_socks[MAX_CLNT];
} Room;

Room rooms[MAX_ROOM];
int room_count = 0;

int main(int argc, char *argv[])
{
    int serv_sock, clnt_sock;
    struct sockaddr_in serv_adr, clnt_adr;
    int clnt_adr_sz;
    pthread_t t_id;

    if (argc != 2) {
        printf("Usage : %s <port>\n", argv[0]);
        exit(1);
    }

    pthread_mutex_init(&mutx, NULL);
    serv_sock = socket(PF_INET, SOCK_STREAM, 0);

    memset(&serv_adr, 0, sizeof(serv_adr));
    serv_adr.sin_family = AF_INET;
    serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_adr.sin_port = htons(atoi(argv[1]));

    if (bind(serv_sock, (struct sockaddr *) &serv_adr, sizeof(serv_adr)) == -1)
        error_handling("bind() error");
    if (listen(serv_sock, 5) == -1)
        error_handling("listen() error");

    while (1) {
        clnt_adr_sz = sizeof(clnt_adr);
        clnt_sock = accept(serv_sock, (struct sockaddr *)&clnt_adr, &clnt_adr_sz);

        pthread_mutex_lock(&mutx);
        clnt_socks[clnt_cnt++] = clnt_sock;
        pthread_mutex_unlock(&mutx);

        pthread_create(&t_id, NULL, handle_clnt, (void *)&clnt_sock);
        pthread_detach(t_id);
        printf("Connected client IP: %s \n", inet_ntoa(clnt_adr.sin_addr));
    }

    close(serv_sock);
    return 0;
}

void *handle_clnt(void *arg)
{
    int clnt_sock = *((int *)arg);
    int str_len = 0;
    char msg[BUF_SIZE];
    char room_name[MAX_ROOM_NAME];
    char response[BUF_SIZE];

    while ((str_len = read(clnt_sock, msg, sizeof(msg))) != 0) {
        msg[str_len] = '\0'; // Null-terminate the string

        if (strncmp(msg, "create_room ", 12) == 0) {
            // Create room
            create_room(msg + 12);
            snprintf(response, sizeof(response), "Room '%s' created and you are now in this room.", msg + 12);
            write(clnt_sock, response, strlen(response));
            enter_room(clnt_sock, msg + 12);  // Automatically enter the created room
        } else if (strcmp(msg, "list_rooms") == 0) {
            // List rooms
            list_rooms(clnt_sock);
        } else if (strncmp(msg, "enter_room ", 11) == 0) {
            // Enter room
            enter_room(clnt_sock, msg + 11);
        } else if (strcmp(msg, "leave_room") == 0) {
            // Leave room
            leave_room(clnt_sock);
        } else {
            // Broadcast message to clients in the same room
            pthread_mutex_lock(&mutx);
            for (int i = 0; i < room_count; i++) {
                for (int j = 0; j < rooms[i].clnt_count; j++) {
                    if (rooms[i].clnt_socks[j] == clnt_sock) {
                        send_msg_to_room(msg, rooms[i].name);
                        pthread_mutex_unlock(&mutx);
                        return;
                    }
                }
            }
            pthread_mutex_unlock(&mutx);
        }
    }

    pthread_mutex_lock(&mutx);
    for (int i = 0; i < clnt_cnt; i++) {
        if (clnt_sock == clnt_socks[i]) {
            while (i++ < clnt_cnt - 1)
                clnt_socks[i] = clnt_socks[i + 1];
            break;
        }
    }
    clnt_cnt--;
    pthread_mutex_unlock(&mutx);
    close(clnt_sock);
    return NULL;
}

void create_room(const char *room_name)
{
    pthread_mutex_lock(&mutx);

    // Check if room already exists
    for (int i = 0; i < room_count; i++) {
        if (strcmp(rooms[i].name, room_name) == 0) {
            pthread_mutex_unlock(&mutx);
            return; // Room already exists
        }
    }

    // Create new room
    if (room_count < MAX_ROOM) {
        strncpy(rooms[room_count].name, room_name, MAX_ROOM_NAME - 1);
        rooms[room_count].name[MAX_ROOM_NAME - 1] = '\0';  // Ensure null termination
        rooms[room_count].clnt_count = 0;
        room_count++;
    }

    pthread_mutex_unlock(&mutx);
}

void list_rooms(int sock)
{
    pthread_mutex_lock(&mutx);

    char response[BUF_SIZE] = "Available rooms:\n";
    for (int i = 0; i < room_count; i++) {
        strcat(response, rooms[i].name);
        strcat(response, "\n");
    }

    pthread_mutex_unlock(&mutx);

    write(sock, response, strlen(response));
}

void enter_room(int sock, const char *room_name)
{
    pthread_mutex_lock(&mutx);

    int room_index = -1;
    for (int i = 0; i < room_count; i++) {
        if (strcmp(rooms[i].name, room_name) == 0) {
            room_index = i;
            break;
        }
    }

    if (room_index != -1) {
        Room *room = &rooms[room_index];
        for (int i = 0; i < room->clnt_count; i++) {
            if (room->clnt_socks[i] == sock) {
                // Already in room
                pthread_mutex_unlock(&mutx);
                write(sock, "You are already in this room.", 30);
                return;
            }
        }
        room->clnt_socks[room->clnt_count++] = sock;
        snprintf(msg, sizeof(msg), "Entered room '%s'.", room_name);
        write(sock, msg, strlen(msg));
        // Notify others in the room
        char notification[BUF_SIZE];
        snprintf(notification, sizeof(notification), "Client has entered room '%s'.", room_name);
        send_msg_to_room(notification, room_name);
    } else {
        write(sock, "Room not found.", 15);
    }

    pthread_mutex_unlock(&mutx);
}

void leave_room(int sock)
{
    pthread_mutex_lock(&mutx);

    for (int i = 0; i < room_count; i++) {
        for (int j = 0; j < rooms[i].clnt_count; j++) {
            if (rooms[i].clnt_socks[j] == sock) {
                // Remove client from room
                for (int k = j; k < rooms[i].clnt_count - 1; k++) {
                    rooms[i].clnt_socks[k] = rooms[i].clnt_socks[k + 1];
                }
                rooms[i].clnt_count--;
                snprintf(msg, sizeof(msg), "Left room '%s'.", rooms[i].name);
                write(sock, msg, strlen(msg));
                // Notify others in the room
                char notification[BUF_SIZE];
                snprintf(notification, sizeof(notification), "Client has left room '%s'.", rooms[i].name);
                send_msg_to_room(notification, rooms[i].name);
                pthread_mutex_unlock(&mutx);
                return;
            }
        }
    }

    write(sock, "You are not in any room.", 25);

    pthread_mutex_unlock(&mutx);
}

void send_msg_to_room(const char *msg, const char *room_name)
{
    pthread_mutex_lock(&mutx);
    for (int i = 0; i < room_count; i++) {
        if (strcmp(rooms[i].name, room_name) == 0) {
            for (int j = 0; j < rooms[i].clnt_count; j++) {
                write(rooms[i].clnt_socks[j], msg, strlen(msg));
            }
            break;
        }
    }
    pthread_mutex_unlock(&mutx);
}

void error_handling(const char *msg)
{
    perror(msg);
    exit(1);
}

